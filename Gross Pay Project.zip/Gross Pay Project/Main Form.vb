' Name:         Gross Pay Project
' Purpose:      Displays an employee's gross pay.
' Programmer:   Marco Gomez on 7/9/2019

Option Explicit On
Option Strict On
Option Infer Off

Public Class frmMain

    Public Sub frmMain_Load(sender As Object, e As EventArgs) Handles Me.Load
        ' Selects the first pay code in the list box.

        lstCodes.SelectedIndex = 0

        'Adds pay rate codes to the list box
        lstCodes.Items.Add("P23")
        lstCodes.Items.Add("P56")
        lstCodes.Items.Add("P45")
        lstCodes.Items.Add("F23")
        lstCodes.Items.Add("F68")
        lstCodes.Items.Add("F96")
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub ClearGross(sender As Object, e As EventArgs) Handles lstCodes.SelectedIndexChanged, txtHours.TextChanged
        lblGross.Text = String.Empty
    End Sub

    Private Sub txtHours_Enter(sender As Object, e As EventArgs) Handles txtHours.Enter
        txtHours.SelectAll()
    End Sub

    Private Sub txtHours_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtHours.KeyPress
        ' Accept only numbers, the period, and the Backspace key.

        If (e.KeyChar < "0" OrElse e.KeyChar > "9") AndAlso e.KeyChar <> "." AndAlso e.KeyChar <> ControlChars.Back Then
            e.Handled = True
        End If
    End Sub

    Private Sub BtnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click

        'Scope of variables including the array of doubles as the payrates.
        'The rest of the variables are created for gross pay calculation purposes.
        Dim ArrPayRate As Double() = {10.5, 12.5, 14.25, 15.75, 17.65}

        'Creates a form of saving a singular value from the array selection
        Dim PayRate As Double
        Dim HrsWorked As Double = Convert.ToDouble(txtHours.Text)
        Dim dblOverTime As Double

        'A Switch case statement that assigns a different payrate value from the array depending
        'on selected case from the list box.
        Select Case lstCodes.SelectedIndex
            Case 0
                PayRate = ArrPayRate(0)
            Case 1
                PayRate = ArrPayRate(1)
            Case 2
                PayRate = ArrPayRate(2)
            Case 3
                PayRate = ArrPayRate(3)
            Case 4
                PayRate = ArrPayRate(4)
        End Select

        'Determines if theres overtime and if there is, overtime hours are calulcated and then 
        'mulyiplied by the payrate times 1.5
        'If no overtime hours exist the hours worked will remain the same and there is no overtime pay.
        If HrsWorked > 40 Then
            dblOverTime = (HrsWorked - 40) * (PayRate * 1.5)
            HrsWorked = 40
        Else
            HrsWorked = HrsWorked
            dblOverTime = 0
        End If

        'Outputs the gross pay
        lblGross.Text = Convert.ToString((PayRate * HrsWorked) + dblOverTime)

    End Sub
End Class
